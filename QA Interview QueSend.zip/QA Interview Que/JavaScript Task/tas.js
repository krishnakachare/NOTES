let num = Math.ceil(Math.random() * 5)
console.log(num)